/*
 * pisicion.h
 *
 *  Created on: Nov 22, 2024
 *      Author: crimi
 */

#ifndef INC_POSICION_H_
#define INC_POSICION_H_
#include "main.h"

#define PI_PROPIO 3.1416
#define wheel_radius_mm 17.5
#define  wheel_base_mm 76
#define pulses_per_revolution 780.0

typedef struct {
    float x;      // Posición en el eje X (mm)
    float y;      // Posición en el eje Y (mm)
    float theta;  // Orientación en radianes
    float velMotorL; //velocidad del motor L (mm/s)
    float velMotorR; //velocidad del motor R (mm/s)
    float velLineal; // Velocidad lineal (mm/s)
    float velAngular; // Velocidad angular (rad/s)
    float avanceLineal;
    float left_distance_mm;
    float right_distance_mm;
    float left_distance_mm_acum;
    float right_distance_mm_acum;
    float velMotorLfir;
    float velMotorRfir;
} Pose;

void InitPose(Pose *pose);
void updatePose(Pose *pose, int16_t pulsosL, int16_t pulsosR, float deltaTiempo);
void pose_reset(Pose *pose);


#endif /* INC_POSICION_H_ */
