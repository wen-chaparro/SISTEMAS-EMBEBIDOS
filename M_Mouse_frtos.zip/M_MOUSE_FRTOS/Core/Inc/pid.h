/*
 * pid.h
 *
 *  Created on: Nov 19, 2024
 *      Author: crimi
 */

#ifndef SRC_PID_H_
#define SRC_PID_H_
#include "main.h"

typedef struct{
	float pKP;
	float pKi;
	float pKd;
	float prevError;
	float acum_Ki;
	float saturacion;
	uint8_t first_run; 
}st_PID;

void pidInit(st_PID *varsPID, float Kp, float ki, float Kd, float saturacion);
float pidUpdate (st_PID *varsPID, float error, float dt ); //tengo que decirle cual error y cuanto tiemmpo
void pidReset(st_PID *varsPID);


#endif /* SRC_PID_H_ */
