


#include "pid.h"




void pidInit(st_PID *varsPID, float Kp, float ki, float Kd, float saturacion){
	varsPID -> pKP = Kp;
	varsPID -> pKi= ki;
	varsPID -> pKd = Kd;
	varsPID -> saturacion = saturacion;
	varsPID -> acum_Ki =0;
	varsPID -> prevError=0;
	varsPID ->first_run=1;
}


float pidUpdate (st_PID *varsPID, float error, float dt ){
	if(varsPID->first_run == 1 ){
		varsPID->first_run = 0;
		varsPID->prevError = error;
	}

	//dt = dt/1000.0; //convertir de milisegundo a segundo

	varsPID->acum_Ki += (error + varsPID->prevError)* 0.5 * dt;

	if (varsPID->acum_Ki > varsPID->saturacion){
		varsPID->acum_Ki = varsPID->saturacion;
	} else if (varsPID->acum_Ki < -varsPID->saturacion){
		varsPID->acum_Ki = -varsPID->saturacion;
	}

	float derivativo = (error - varsPID->prevError)/dt;

	varsPID->prevError = error;

	return (varsPID->pKP * error)+ (varsPID->pKi * varsPID->acum_Ki)+(varsPID->pKd * derivativo);
}


void pidReset(st_PID *varsPID){
	varsPID->first_run=1;
	varsPID->acum_Ki=0;
	varsPID->prevError=0;

}
