/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "math.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"


#include "queue.h" // libreria de teoría colas
#include "task.h" // SEMAFORO
#include "semphr.h" // SEMAFORO
#include "pid.h"
#include "posicion.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim9;
TIM_HandleTypeDef htim10;
TIM_HandleTypeDef htim11;

UART_HandleTypeDef huart6;

osThreadId ADCHandle;
uint32_t ADCBuffer[ 256 ];
osStaticThreadDef_t ADCControlBlock;
osThreadId MOTORESHandle;
uint32_t MOTORESBuffer[ 1024 ];
osStaticThreadDef_t MOTORESControlBlock;
osThreadId PULSADORHandle;
uint32_t PULSADORBuffer[ 128 ];
osStaticThreadDef_t PULSADORControlBlock;
/* USER CODE BEGIN PV */

/////////////////////////////////////Parametros fijos
#define motorVolts 7.4 // VOLTAJE MAXIMO
#define cpDefinido 200.0 //CP ESCOGIDO PARA 30KHz
#define mm_pulsos 0.141 //EQUIVALENCIA DE CADA PULSO EN mm
float max_speed= 200;  //VELOCIDAD MAXIMA ESCOGIDA
float min_speed = 100; //VELOCIDAD MINIMA ESCOGIDA
float acceleration = 500;
float acceleration_turn = 400;
float pared_frontal=40.0; //DISTANCIA MINIMA ENTRE PARED FRONTAL Y MICRO MOUSE
float pared_lados=45.0;   //DISTANCIA MINIMA ENTRE PAREDES LATERALES Y MICRO MOUSE
float bateriaVolts= 0.0;
float mm_deseados=180.0; //DISTANCIA FRONTAL QUE SE DEBE RECORRER PARA AVANZAR ENTRE CELDAS
float vuelta=59.6; // DISTANCIA QUE SE DEBE RECORRER PARA DAR UNA VUELTA
//////////////////////////////////////////////////////

st_PID PID_speedL;
st_PID PID_speedR;
st_PID PID_distL;
st_PID PID_distR;
Pose posicion;
float velocidad_L;
float velocidad_R;
float outspeedL=0;
float outspeedR=0;
float outmmL=0;
float outmmR=0;
char texto[128];
float mm_2=0;
float mm_3=0;
float tiempo_acumulado = 0.0;


//Variables asociadas a posicion
int16_t objetivo = 0;
int16_t objetivo_negativo=0;
float error_paredL= 0.0;
float error_paredR= 0.0;

/*int16_t	antencoder_1 = 0;
int16_t	antencoder_2 = 0;
float deltaTiempo = 0;
float deltaTiempoms=0;*/


////////////////////////////////////
char counter=0;//PULSACIONES
char modo=0;//MODO DE FUNCIONAMIENTO
float bateria=0;

//////////////////////////////////////

char flag2 = 0;
char flag = 0;
char flag1 = 0;
uint16_t sensores_1[4];

//variables asociadas con encoder
int16_t encoder_1 = 0;
int16_t encoder_2 = 0;
int16_t	antencoder_1 = 0;
int16_t	antencoder_2 = 0;
////////////////////////////////

//perfil trapezoidal
float x_s = 0.0;
float x_e = 0.0;
float x_f = 0.0;
float d_a = 0.0;
float d_b = 0.0;
float d_c = 0.0;

float velocidad_izquierda=0.0;
float velocidad_derecha=0.0;
float distancia = 0.0;

char check=0;
char derecha= 0;
char izquierda = 0;

//milimetros calibrados
int mms[] = {
    5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0,
    55.0, 60.0, 65.0, 70.0, 75.0, 80.0, 85.0, 90.0, 95.0, 100.0};

//Calibracion de sensores en funcion de distancia mms(milimetros)
int S1_ADC[] = {3527, 2619, 2214, 1653, 1330, 1192, 951, 763, 646, 582, 517, 443, 422, 369, 318, 306, 278, 248, 233, 226};
int S2_ADC[] = {3856, 3266, 2694, 1852, 1397, 1044, 754, 556, 421, 322, 248, 201, 149, 122, 92, 77, 62, 47, 42, 37};
int S3_ADC[] = {3900, 3803, 3585, 2931, 2364, 1832, 1520, 1241, 1005, 862, 740, 658, 576, 503, 464, 420, 384, 353, 334, 307};
int S4_ADC[] = {3891, 3846, 3630, 2991, 2691, 2094, 1771, 1464, 1222, 1059, 921, 843, 743, 685, 588, 500, 461, 426, 412, 370};


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM10_Init(void);
static void MX_TIM5_Init(void);
static void MX_TIM9_Init(void);
static void MX_USART6_UART_Init(void);
static void MX_TIM11_Init(void);
void ADCDefaultTask(void const * argument);
void MOTORESTask02(void const * argument);
void PULSADORTask03(void const * argument);

/* USER CODE BEGIN PFP */
void CalculoPID(float deltaTiempo);
void InicioPID();
void distancia_pared(float deltaTiempo);
void detectar_pulsos();
void funcionamiento(char pulsos );
void perfil_velocidad(float distancia);
void objetivo_mm();
void objetivo_mm_giros();
void mm_VoltsM1(float mm);
void mm_VoltsM2(float mm_);
void voltpwm_m1(float voltios_1);
void voltpwm_m2(float voltios_2);
void avanzar(char direccion);
void reset(char check);
float cambio_sensor(char no);
float valor_voltaje(uint32_t adc);
void decision(uint16_t mm_actual, uint16_t mm_derecha, uint16_t mm_izquierda);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void ADC_Init_Custom(){

	  hadc1.Instance = ADC1;
	  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
	  hadc1.Init.ScanConvMode = ENABLE;
	  hadc1.Init.ContinuousConvMode = ENABLE;
	  hadc1.Init.DiscontinuousConvMode = DISABLE;
	  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	  hadc1.Init.NbrOfConversion = 1;
	  hadc1.Init.DMAContinuousRequests = DISABLE;
	  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	  if (HAL_ADC_Init(&hadc1) != HAL_OK)
	  {
	    Error_Handler();
	  }

}

uint32_t ADC_SelectCH(uint32_t Channel){

	ADC_ChannelConfTypeDef sConfig = {0};
	uint32_t result;

	  sConfig.Channel = Channel;
	  sConfig.Rank = 1;
	  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		Error_Handler();
	  }

	HAL_ADC_Start(&hadc1);
	HAL_ADC_PollForConversion(&hadc1, 100);
	result= HAL_ADC_GetValue(&hadc1);
	HAL_ADC_Stop(&hadc1);
	return result;
}
SemaphoreHandle_t mutex1;
xQueueHandle sensores;//cola para los sensores
xQueueHandle source;//Cola para la bateria

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM10_Init();
  MX_TIM5_Init();
  MX_TIM9_Init();
  MX_USART6_UART_Init();
  MX_TIM11_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of ADC */
  osThreadStaticDef(ADC, ADCDefaultTask, osPriorityNormal, 0, 256, ADCBuffer, &ADCControlBlock);
  ADCHandle = osThreadCreate(osThread(ADC), NULL);

  /* definition and creation of MOTORES */
  osThreadStaticDef(MOTORES, MOTORESTask02, osPriorityNormal, 0, 1024, MOTORESBuffer, &MOTORESControlBlock);
  MOTORESHandle = osThreadCreate(osThread(MOTORES), NULL);

  /* definition and creation of PULSADOR */
  osThreadStaticDef(PULSADOR, PULSADORTask03, osPriorityNormal, 0, 128, PULSADORBuffer, &PULSADORControlBlock);
  PULSADORHandle = osThreadCreate(osThread(PULSADOR), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  HAL_TIM_Base_Start(&htim1);
  HAL_TIM_Base_Start(&htim4);
  HAL_TIM_Base_Start(&htim5);
  HAL_TIM_Base_Start(&htim9);
  HAL_TIM_Base_Start(&htim11);
  HAL_TIM_PWM_Start(&htim10, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 16-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 200;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 0;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim4, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 19200-1;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 65535;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * @brief TIM9 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM9_Init(void)
{

  /* USER CODE BEGIN TIM9_Init 0 */

  /* USER CODE END TIM9_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};

  /* USER CODE BEGIN TIM9_Init 1 */

  /* USER CODE END TIM9_Init 1 */
  htim9.Instance = TIM9;
  htim9.Init.Prescaler = 19200-1;
  htim9.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim9.Init.Period = 65535;
  htim9.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim9.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim9) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim9, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM9_Init 2 */

  /* USER CODE END TIM9_Init 2 */

}

/**
  * @brief TIM10 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM10_Init(void)
{

  /* USER CODE BEGIN TIM10_Init 0 */

  /* USER CODE END TIM10_Init 0 */

  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM10_Init 1 */

  /* USER CODE END TIM10_Init 1 */
  htim10.Instance = TIM10;
  htim10.Init.Prescaler = 16-1;
  htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim10.Init.Period = 200;
  htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim10, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM10_Init 2 */

  /* USER CODE END TIM10_Init 2 */
  HAL_TIM_MspPostInit(&htim10);

}

/**
  * @brief TIM11 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM11_Init(void)
{

  /* USER CODE BEGIN TIM11_Init 0 */

  /* USER CODE END TIM11_Init 0 */

  /* USER CODE BEGIN TIM11_Init 1 */

  /* USER CODE END TIM11_Init 1 */
  htim11.Instance = TIM11;
  htim11.Init.Prescaler = 19200-1;
  htim11.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim11.Init.Period = 65535;
  htim11.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim11.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim11) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM11_Init 2 */

  /* USER CODE END TIM11_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 460800;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA5 PA6 PA7 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB3 PB4 PB5
                           PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB12 */
  GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void detectar_pulsos(){
	 if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12)==0){// revisar si se ha pulsado el boton
		 uint16_t espera=0;
		 while(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12)==0){//mientras este pulsado 1s o menos modo 1
			 espera++;
			 osDelay(10);
			 if(espera == 100 ){
				 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14,1);
				 osDelay(50);
				 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14,0);
				 counter++;
			 }
			 if(espera == 200){//mientras este pulsado 2s modo 2
				 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14,1);
				 osDelay(50);
				 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14,0);
				 counter++;
			 }
			 if(espera== 300){//mientras este pulsado 3s modo 3
				 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14,1);
				 osDelay(50);
				 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14,0);
				 counter++;
			 }
		 }
	 }
}

void funcionamiento(char pulsos ){

	 if(pulsos == 1){
		 modo = 1;
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,1);
		 osDelay(500);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,0);
		 counter = 0;
		 flag1=0;
		 __HAL_TIM_SET_COUNTER(&htim5,0);
		 osDelay(300);
	 }

	 if(pulsos == 2){
		 modo = 0;
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,1);
		 osDelay(100);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,0);
		 osDelay(100);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,1);
		 osDelay(100);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,0);
		 counter = 0;

	 }

	 if(pulsos == 3){
		 modo = 3; //llegada
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,1);
		 osDelay(50);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,0);
		 osDelay(50);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,1);
		 osDelay(50);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,0);
		 osDelay(50);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,1);
		 osDelay(50);
		 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,0);
		 counter = 0;
	 }

}

void CalculoPID(float deltaTiempoms){

	 encoder_2= __HAL_TIM_GET_COUNTER(&htim4); //encoderR
	 encoder_1= __HAL_TIM_GET_COUNTER(&htim1); //encoderL


	 updatePose(&posicion, (encoder_2-antencoder_2), (encoder_1-antencoder_1), (deltaTiempoms));

	 float error_speed_L = velocidad_izquierda - posicion.velMotorLfir;
	 float error_speed_R = velocidad_derecha - posicion.velMotorRfir;

	 antencoder_1=encoder_1;
	 antencoder_2=encoder_2;

	 outspeedR = pidUpdate(&PID_speedR, error_speed_R, deltaTiempoms);
	 outspeedL = pidUpdate(&PID_speedL, error_speed_L, deltaTiempoms);

}
void InicioPID(){
	static char inicioPID = 0;
	if(inicioPID==0){
		InitPose(&posicion);
		pidInit(&PID_speedL, 0.090, 0.00009, 0.00004, 2000.0);//m2
		pidInit(&PID_speedR, 0.00015, 0.000004, 0.00002, 2000.0);//m1
		pidInit(&PID_distL, 0.050, 0.0, 0.0, 2000.0);
		pidInit(&PID_distR, 0.080, 0.0, 0.0, 2000.0);
		inicioPID=1;
	}
}

void decision(uint16_t mm_actual, uint16_t mm_derecha, uint16_t mm_izquierda){

	if(modo==1){
		 if(mm_actual > 65){//avanzar cuando no ve nada
			 if(mm_derecha > 65){
				 if(mm_izquierda > 65){
					 avanzar(1);
				 }
			 }
		 }
		 if(mm_actual > 65){//avanzar
			 if(mm_derecha < 65){
				 if(mm_izquierda < 65){
					 avanzar(1);
				 }
			 }
		 }
		 if(mm_actual > 65){//prioridad seguir derecho entre girar a un lado o seguir
			 if(mm_derecha < 65){
				 if(mm_izquierda > 65){
					 avanzar(1);
				 }
			 }
		 }
		 if(mm_actual > 65){//prioridad seguir derecho entre girar a un lado o seguir
			 if(mm_derecha > 65){
				 if(mm_izquierda < 65){
					 avanzar(1);
				 }
			 }
		 }
		 if(mm_actual < 65){//prioridad giro derecha
			 if(mm_derecha > 65){
				 if(mm_izquierda > 65){
					 avanzar(2);
					 }
			 }
		 }
		 if(mm_actual < 65){//derecha
			 if(mm_derecha > 65){
				 if(mm_izquierda < 65){
					 avanzar(2);
				 }
			 }
		 }
		 if(mm_actual <  65){//izquierda
			 if(mm_derecha < 65){
				 if(mm_izquierda > 65){
					 avanzar(3);
				 }
			 }
		 }
		 if(mm_actual < 65){//toda la vuelta
			 if(mm_derecha < 65){
				 if(mm_izquierda < 65){
					 avanzar(4);
				 }
			 }
		 }
		 reset(check);
	 }
}

void perfil_velocidad(float mm_total){
	 distancia=mm_total;
	 static float distancia_promedio =0;
	 static float velocidad=0;


	 tiempo_acumulado = __HAL_TIM_GET_COUNTER(&htim5) * 0.0002;
	 __HAL_TIM_SET_COUNTER(&htim5,0);

	 if(flag==2){
		 velocidad_derecha= min_speed;
		 velocidad_izquierda= min_speed;
		 flag = 0;
		 x_s = max_speed/acceleration;
		 d_a = (x_s*(max_speed-min_speed))/2;
		 d_c = (x_s*(max_speed-min_speed))/2;
		 d_b = (distancia-d_a-d_c);
		 x_e = x_s + (d_b/max_speed);
		 x_f = x_s + x_e;
		 velocidad=min_speed;
	 }

	 distancia_promedio = posicion.avanceLineal;


	 // Fase de aceleración
	 if (distancia_promedio < d_a) {


		 if( velocidad > max_speed){
			 velocidad_derecha = max_speed;
			 velocidad_izquierda = max_speed;
		 }else{
			 velocidad+=acceleration * tiempo_acumulado;
			 velocidad_derecha += acceleration * tiempo_acumulado;
			 velocidad_izquierda += acceleration * tiempo_acumulado;
		 }
	 }


	 // Fase de velocidad constante
	 else if ( distancia_promedio < (d_b+d_a)) {
		 velocidad_derecha = max_speed;
		 velocidad_izquierda = max_speed;
	 }

	 // Fase de desaceleración
	 else if( distancia_promedio < (distancia) ) {

		 if(velocidad_izquierda < min_speed ){
			 velocidad_derecha= min_speed;
			 velocidad_izquierda= min_speed;
		 }else{
			 velocidad_derecha -=  acceleration * tiempo_acumulado ;
			 velocidad_izquierda -= acceleration * tiempo_acumulado ;
		 }
	 }



	 CalculoPID(tiempo_acumulado);
	 distancia_pared(tiempo_acumulado);
	 if(derecha==0 && izquierda==0){
		 objetivo_mm();
	 }if(derecha==1 || izquierda==1){
		 objetivo_mm_giros();
	 }
	 osDelay(3);

}

void objetivo_mm(){

	objetivo=distancia/mm_pulsos;

	 encoder_2= __HAL_TIM_GET_COUNTER(&htim4);
	 encoder_1= __HAL_TIM_GET_COUNTER(&htim1);

	 if(objetivo !=  encoder_1){
		 if(objetivo > encoder_1){

			 mm_VoltsM1(velocidad_derecha+outspeedR+24+outmmR);

		 }else if(objetivo < encoder_1){

			mm_VoltsM1((-1)*(velocidad_derecha+outspeedR+24+outmmR));

		 }
	 }else{
		 mm_VoltsM1(0);

	 }

	 if(encoder_2 != objetivo){
		 if(objetivo > encoder_2){

			 mm_VoltsM2(velocidad_izquierda+outspeedL+outmmL);

		 }else if(objetivo < encoder_2){

			 mm_VoltsM2((-1)*(velocidad_izquierda+outspeedL+outmmL));
		 }
	}else{
		mm_VoltsM2(0);

	}
}

void objetivo_mm_giros(){

	objetivo=distancia/mm_pulsos;
	objetivo_negativo=-objetivo;

	 encoder_2= __HAL_TIM_GET_COUNTER(&htim4);
	 encoder_1= __HAL_TIM_GET_COUNTER(&htim1);

	 if(izquierda==1){
		 if(objetivo !=  encoder_1){
			 if(objetivo > encoder_1){

				mm_VoltsM1(velocidad_derecha+outspeedR+24+outmmR);

			 }else if(objetivo < encoder_1){

				 mm_VoltsM1((-1)*(velocidad_derecha+outspeedR+24+outmmR));

			 }
		 }else{
			 mm_VoltsM1(0);

		 }

		 if(encoder_2 != objetivo_negativo){
			 if(objetivo_negativo > encoder_2){

				 mm_VoltsM2(velocidad_izquierda+outspeedL+outmmL);

			 }else if(objetivo_negativo < encoder_2){

				 mm_VoltsM2((-1)*(velocidad_izquierda+outspeedL+outmmL));
			 }
		}else{
			mm_VoltsM2(0);

		}

	}
	 if(derecha==1 ){
		 if( encoder_1 != objetivo_negativo){

			 if(objetivo_negativo > encoder_1){

				 mm_VoltsM1(velocidad_derecha+outspeedR+24+outmmR);

			 }else if(objetivo_negativo < encoder_1){

				 mm_VoltsM1((-1)*(velocidad_derecha+outspeedR+24+outmmR));


			 }
		 }else{
			 mm_VoltsM1(0);
		 }

		 if(encoder_2 != objetivo){
			 if(objetivo > encoder_2){

				 mm_VoltsM2(velocidad_izquierda+outspeedL+outmmL);

			 }else if(objetivo < encoder_2){

				 mm_VoltsM2((-1)*(velocidad_izquierda+outspeedL+outmmL));
			 }
		}else{
			mm_VoltsM2(0);
		}
	}

}

void distancia_pared(float deltaTiempo){
	static float derecha_mm=0;
	static float izquierda_mm=0;

	 izquierda_mm=mm_2;
	 error_paredL=pared_lados-izquierda_mm;


	 derecha_mm=mm_3;
	 error_paredR=pared_lados-derecha_mm;


	outmmR = pidUpdate(&PID_distR, 2*error_paredR, (deltaTiempo));
	outmmL = pidUpdate(&PID_distL, 2*error_paredL, (deltaTiempo));

	if(error_paredL < 0){
        outmmR=(-1)*(outmmR);
        outmmL=(-1)*(outmmL);
	}else if (error_paredL > 0){
        outmmR=(-1)*(outmmR);
        outmmL=(-1)*(outmmL);
	}
}

void avanzar(char direccion) {
	switch(direccion) {
        case 1: //hacia adelante
			if(flag1==0){
				flag=2;
				flag1++;
			 }

			 while(1){
				 perfil_velocidad(mm_deseados);
				 sprintf(texto,"%.2f %.2f %.2f %f \n\r", posicion.velMotorLfir,posicion.velMotorRfir, velocidad_derecha,tiempo_acumulado);
				 HAL_UART_Transmit(&huart6, texto,strlen(texto),100);

				 if(abs(objetivo - encoder_1) <= 6  && abs(objetivo - encoder_2) <= 6 ){
					 break;
				 }

			 }
			 check=1;
			 break;

        case 2: //hacia la derecha
	 		 derecha=1;
	 		 if(flag1==0){
	 		 flag=2;
	 		 flag1++;
	 		 }
	 		while(1){
				perfil_velocidad(vuelta);
				if( abs(objetivo_negativo+(-encoder_1)) <= 4 && abs(objetivo - encoder_2) <= 4 ){
					break;
				}
			}
			check=1;
	 		break;

        case 3: //hacia la Izquierda
	 		 izquierda=1;
	 		 if(flag1==0){
	 		 flag=2;
	 		 flag1++;
	 		 }
			while(1){
				perfil_velocidad(vuelta);
				if(abs(objetivo_negativo+(-encoder_2)) <= 4 && abs(objetivo - encoder_1) <= 4){
					break;
				}
			}
			check=1;
			break;

        case 4: //vuelta completa
        	derecha=1;
        	if(flag1==0){
				 flag=2;
				 flag1++;
			 }
	 		while(1){
				perfil_velocidad(vuelta*2);
				if(abs(objetivo_negativo+(-encoder_1)) <=4 && abs(objetivo - encoder_2) <= 4){
					break;
				}
			}
			check=1;
			break;
    }
}

void mm_VoltsM1(float mm){
	float volts_1=0;
	float pwm_cp1=0;

	if(mm > 0.0){//Derecha
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,1);
		volts_1= (mm - 49.138) / 64.841;
		pwm_cp1=(cpDefinido*volts_1)/motorVolts;
		__HAL_TIM_SET_COMPARE(&htim10, TIM_CHANNEL_1, pwm_cp1);


	}
	if (mm < 0.0) {//se verifica si tiene signo negativo (Izquierda
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,0);
		volts_1 = ( abs(mm) - 49.138 )/ 64.841;
		pwm_cp1=(cpDefinido*volts_1)/motorVolts;
		__HAL_TIM_SET_COMPARE(&htim10, TIM_CHANNEL_1, pwm_cp1);

	}
	if(mm==0){
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4,0);

	}
}

void mm_VoltsM2( float mm_ ){

	float volts_2=0;
	float pwm_cp2=0;

	if(mm_ > 0){//Derecha
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,1);
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,0);
		volts_2 = (mm_- 30.295)/64.961;
		pwm_cp2=(cpDefinido*volts_2)/motorVolts;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, pwm_cp2);





	}
	if (mm_ < 0) {//se verifica si tiene signo negativo (Izquierda
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,0);
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,1);
		volts_2 =( abs(mm_)-30.295)/64.961;
		pwm_cp2=(cpDefinido*volts_2)/motorVolts;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, pwm_cp2);




	}
	if(mm_==0){
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,0);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,0);
			__HAL_TIM_SET_COMPARE(&htim10, TIM_CHANNEL_1,0);

		}
}

float valor_voltaje(uint32_t adc){ //Función para convertir de adc a volts
	float voltios=(adc*3.3)/4095;
	return voltios;
}

float cambio_sensor(char contador){
	uint32_t adc;
	static float mm=0;
	unsigned char veces=0;//PROMEDIO
	static float volts=0;

	  if(contador==0){
		  uint32_t S1 = 0;
		  static uint32_t S1_acum=0;
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,1);
		  while(veces != 11){
			  S1 = ADC_SelectCH(ADC_CHANNEL_0);
			  if(veces!=0){
				S1_acum+=S1;
			  }
			  veces++;
		  }
		  adc=(S1_acum/10);
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,0);


		  for(int i=0; i<20; i++){
			  if(adc<S1_ADC[19]){
				  mm=100;
				  S1_acum=0;
				  veces=0;
			  }
			  else if(adc>S1_ADC[i] && adc<S1_ADC[i-1]){
				  int y1=mms[i];
				  int y2=mms[i-1];
				  float x1= valor_voltaje(S1_ADC[i]);
				  float x2= valor_voltaje(S1_ADC[i-1]);
				  float m = (y2-y1)/(x2-x1);
				  float b= y1-(m*x1);
				  volts= valor_voltaje(adc);
				  mm= volts*m + b;
			  }
		  }
		  S1_acum=0;
	  }
	  if(contador==1){
		uint32_t S2 = 0;
		static uint32_t S2_acum=0;
		  while(veces != 11){
			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,1);
			  S2 = ADC_SelectCH(ADC_CHANNEL_1);
			  veces++;
			  S2_acum+=S2;
		  }
		  adc = (S2_acum / 10);
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, 0);

		  for (int i = 0; i < 20; i++) {
		      if (adc < S2_ADC[19]) {
		          mm = 100;
		          mm_2=100;
		          S2_acum = 0;
		      }
		      else if (adc > S2_ADC[i] && adc < S2_ADC[i - 1]) {
		          int y1 = mms[i];
		          int y2 = mms[i + 1];
		          float x1 = valor_voltaje(S2_ADC[i]);
		          float x2 =  valor_voltaje(S2_ADC[i - 1]);
		          float m = (y2 - y1) / (x2 - x1);
		          float b = y1 - (m * x1);
		          mm = valor_voltaje(adc) * m + b;
		          mm_2=valor_voltaje(adc) * m + b;
		      }
		  }


		  S2_acum=0;
	  }
	  if(contador==2){
		uint32_t S3 = 0;
		static uint32_t S3_acum=0;
		  while(veces != 11){
			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,1);
			  S3 = ADC_SelectCH(ADC_CHANNEL_2);
			  veces++;
			  S3_acum+=S3;

		  }

		  adc = (S3_acum / 10);
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, 0);

		  for (int i = 0; i < 20; i++) {
		      if (adc < S3_ADC[19]) {
		          mm = 100;
		          mm_3=100;
		          S3_acum = 0;

		      }
		      else if (adc > S3_ADC[i] && adc < S3_ADC[i - 1]) {
		          int y1 = mms[i];
		          int y2 = mms[i + 1];
		          float x1 = valor_voltaje(S3_ADC[i]);
		          float x2 = valor_voltaje(S3_ADC[i - 1]);
		          float m = (y2 - y1) / (x2 - x1);
		          float b = y1 - (m * x1);
		          mm = valor_voltaje(adc) * m + b;
		          mm_3=valor_voltaje(adc) * m + b;
		      }
		  }

		  S3_acum=0;
	  }
	  if(contador==3){
		  uint32_t S4 = 0;
		  static uint32_t S4_acum=0;
		  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0,1);
		  while(veces != 11){
			  S4 = ADC_SelectCH(ADC_CHANNEL_3);
			  S4_acum+=S4;
			  veces++;
		  }
		  adc = (S4_acum / 10);
		  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, 0);

		  for (int i = 0; i < 20; i++) {
		      if (adc < S4_ADC[19]) {
		          mm = 100;
		          S4_acum = 0;

		      }
		      else if (adc > S4_ADC[i] && adc < S4_ADC[i - 1]) {
		          int y1 = mms[i];
		          int y2 = mms[i - 1];
		          float x1 = valor_voltaje(S4_ADC[i]);
		          float x2 = valor_voltaje(S4_ADC[i - 1]);
		          float m = (y2 - y1) / (x2 - x1);
		          float b = y1 - (m * x1);
		          volts= valor_voltaje(adc);
		          mm = volts * m + b;
		      }
		  }

		  S4_acum=0;
	  }
	  if( contador ==4){
		  uint32_t batt = 0;
		  static uint32_t bateria_acum=0;
		  while(veces != 11){
			  batt = ADC_SelectCH(ADC_CHANNEL_4);
			  bateria_acum+=batt;
			  veces++;
		  }
		  adc = (bateria_acum / 10);
		  bateria=2920*(valor_voltaje(adc))/960;
		  bateria_acum=0;
	  }
	  return mm;
}

void reset(char check_){
	if(check_==1){
		__HAL_TIM_SET_COUNTER(&htim4,0); //ENCODER 2
		__HAL_TIM_SET_COUNTER(&htim1,0); //ENCODER 1
		encoder_1=0;
		encoder_2=0;
		check = 0;
		flag1= 0;
		derecha = 0;
		izquierda = 0;
		pidReset(&PID_speedL);
		pidReset(&PID_speedR);
		pidReset(&PID_distL);
		pidReset(&PID_distR);
		pose_reset(&posicion);
		antencoder_1 = 0;
		antencoder_2 = 0;
		//osDelay(2);
	}
}

/* USER CODE END 4 */

/* USER CODE BEGIN Header_ADCDefaultTask */
/**
  * @brief  Function implementing the ADC thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_ADCDefaultTask */
void ADCDefaultTask(void const * argument)
{
  /* USER CODE BEGIN 5 */
  	//char texto[128];
	uint16_t datos_sensores[4];
	sensores= xQueueCreate(1,sizeof(datos_sensores));// crear un colo de un "cajon del espacio de la variable prueba"

  /* Infinite loop */
  for(;;)
  {
	  if(sensores==0){
		  continue;
	  }

	  for(int i=0; i<5; i++ ){
		  if(i<4){
			  datos_sensores[i] = cambio_sensor(i);
		  }
		  else{
			  cambio_sensor(i);
			  bateriaVolts=(2920*bateria)/960;

		  }



	  }
  xQueueOverwrite(sensores,datos_sensores);

  //pdMS_TO_TICKS(2000);//pasar de tick de relos a milisegundos
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_MOTORESTask02 */
/**
* @brief Function implementing the MOTORES thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_MOTORESTask02 */
void MOTORESTask02(void const * argument)
{
  /* USER CODE BEGIN MOTORESTask02 */

  /* Infinite loop */
  for(;;)
  {

	InicioPID();
	if(pdPASS==xQueueReceive(sensores, sensores_1,0)){
		decision((sensores_1[0]+sensores_1[3])/2, sensores_1[2], sensores_1[1]);
	}

  }
  /* USER CODE END MOTORESTask02 */
}

/* USER CODE BEGIN Header_PULSADORTask03 */
/**
* @brief Function implementing the PULSADOR thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_PULSADORTask03 */
void PULSADORTask03(void const * argument)
{
  /* USER CODE BEGIN PULSADORTask03 */

  /* Infinite loop */
  for(;;)
  {
	  detectar_pulsos();//funcion para detectar cantidad de pulsos
	  funcionamiento(counter);//funcion para determinar el funcionamiento
  }
  /* USER CODE END PULSADORTask03 */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM2 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM2) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
