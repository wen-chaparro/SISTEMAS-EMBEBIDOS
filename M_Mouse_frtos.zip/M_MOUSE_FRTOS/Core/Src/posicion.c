/*
 * posicion.c
 *
 *  Created on: Nov 22, 2024
 *      Author: crimi
 */

#include "posicion.h"
#include "math.h"
#define FILTER_TAPS 25  // Número de coeficientes del filtro FIR

// Coeficientes del filtro FIR (esto debe ajustarse según tu diseño específico)
const float fir_coefficients[FILTER_TAPS] = {
    0.002, 0.004, 0.006, 0.008, 0.01, 0.012, 0.014, 0.016, 0.018, 0.02,
    0.02, 0.018, 0.016, 0.014, 0.012, 0.01, 0.008, 0.006, 0.004, 0.002,
    0.001, 0.001, 0.001, 0.001, 0.001
};

// Buffers circulares para almacenar los datos más recientes
float vel1_buffer[FILTER_TAPS] = {0};
int buffer1_index = 0;  // Índice actual en el buffer 1
float vel2_buffer[FILTER_TAPS] = {0};
int buffer2_index = 0;  // Índice actual en el buffer 2

void InitPose(Pose *pose){
	pose-> left_distance_mm = 0.0;
	pose-> right_distance_mm = 0.0;
	pose-> left_distance_mm_acum = 0.0;
	pose-> right_distance_mm_acum = 0.0;
	pose-> x = 0.0;
	pose-> y = 0.0;
	pose-> theta = 0.0;
	pose-> velLineal = 0.0;
	pose-> avanceLineal = 0.0;
	pose-> velMotorL = 0.0;
	pose-> velMotorR = 0.0;
	pose->velAngular = 0.0;
}

void updatePose(Pose *pose,  int16_t pulsosL,  int16_t pulsosR, float delta_time_s){
    pose-> left_distance_mm = (2.0 * PI_PROPIO * wheel_radius_mm * (float)pulsosL) / pulses_per_revolution;
    pose-> right_distance_mm = (2.0 * PI_PROPIO * wheel_radius_mm * (float)pulsosR) / pulses_per_revolution;
    pose->left_distance_mm_acum += pose -> left_distance_mm;
    pose-> right_distance_mm_acum += pose -> right_distance_mm;

    // Distancia promedio recorrida
    //float delta_time_s=deltaTiempo/1000;
    float delta_lineal = (pose -> left_distance_mm + pose -> right_distance_mm) / 2.0;
    pose -> avanceLineal += delta_lineal;
    pose -> velLineal = delta_lineal / delta_time_s;  // Velocidad en mm/s
    pose -> velMotorL = pose -> left_distance_mm / delta_time_s;
    pose -> velMotorR = pose -> right_distance_mm / delta_time_s;

    vel1_buffer[buffer1_index]= pose->velMotorL;
    buffer1_index = (buffer1_index+1)% FILTER_TAPS;

    float vel_filtradoL=0;
    int j = buffer1_index;
    for (int i = 0; i < FILTER_TAPS; i++) {
    	j= (j==0) ? FILTER_TAPS-1 : j-1;
    	vel_filtradoL += fir_coefficients[i]*vel1_buffer[j];
	}
    pose->velMotorLfir=vel_filtradoL;

    vel2_buffer[buffer2_index]= pose->velMotorR;
    buffer2_index = (buffer2_index+1)% FILTER_TAPS;

    float vel_filtradoR=0;
    int k = buffer2_index;
    for (int i = 0; i < FILTER_TAPS; i++) {
    	k= (k==0) ? FILTER_TAPS-1 : k-1;
    	vel_filtradoR += fir_coefficients[i]*vel2_buffer[j];
	}
    pose->velMotorRfir=vel_filtradoR;

    float delta_angular = (pose -> right_distance_mm - pose -> left_distance_mm) / wheel_base_mm;
    pose -> velAngular = delta_angular / delta_time_s;  // Velocidad angular en rad/s

    pose -> theta += delta_angular;
    if(pose -> theta > M_PI) pose -> theta -= 2.0 * M_PI;
    else if(pose -> theta < -M_PI) pose -> theta += 2.0 * M_PI;
    //pose.theta = fmod(pose.theta, 2.0 * M_PI);  // Normalizar ángulo
    pose -> x += delta_lineal * cos(pose -> theta);
    pose -> y += delta_lineal * sin(pose -> theta);
}

void pose_reset(Pose *pose){
	pose-> left_distance_mm = 0.0;
	pose-> right_distance_mm = 0.0;
	pose-> left_distance_mm_acum = 0.0;
	pose-> right_distance_mm_acum = 0.0;
	pose-> x = 0.0;
	pose-> y = 0.0;
	pose-> theta = 0.0;
	pose-> velLineal = 0.0;
	pose-> avanceLineal = 0.0;
	pose-> velMotorL = 0.0;
	pose-> velMotorR = 0.0;
	pose->velAngular = 0.0;
	pose->velMotorLfir=0.0;
	pose->velMotorLfir=0.0;
}
