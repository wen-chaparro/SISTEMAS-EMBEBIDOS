/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usbd_cdc_if.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim10;

/* USER CODE BEGIN PV */
#define motorVolts 7.4
#define cpDefinido 200.0

int objetivo = 780;

volatile uint16_t datosRX[64];
volatile unsigned char indiceRX = 0;

uint16_t espera = 0;
char espera1 = 0;
uint32_t S1 =0;
uint32_t  S2 = 0;
uint32_t S3 = 0;
uint32_t S4 = 0;

uint32_t S1_acum=0;
uint32_t S2_acum=0;
uint32_t S3_acum=0;
uint32_t S4_acum=0;
uint8_t mm_1 = 0;
uint8_t mm_2 = 0;
uint8_t mm_3 = 0;
uint8_t mm_4 = 0;


uint16_t mm_deseados=0;
uint32_t adc = 0;
int volts_ =0;
float volts=0;
float pwm_cp=0;
char negativo=0;
char counter=0;

uint32_t texto[128];
unsigned char veces = 0;
char contador = 0;
char flag = 0;
char giro = 0;


int16_t encoder_1 = 0;
int16_t encoder_2 = 0;
uint16_t anterior_e1 = 0;
uint16_t anterior_e2 = 0;

uint16_t velocidad_m1 = 0.0;
uint16_t velocidad_m2 = 0.0;

int mms[] = {
    5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0,
    55.0, 60.0, 65.0, 70.0, 75.0, 80.0, 85.0, 90.0, 95.0, 100.0,105.0,110.0,115.0 };


int S1_ADC[] = {3931, 3919, 3897, 3858, 3627, 2905, 2354, 1922, 1634,1416, 1207, 1058, 960, 889, 817, 750, 692, 669, 629, 599, 580, 541};
int S2_ADC[] = {120, 107, 102, 96, 90, 93, 92, 92, 91, 91, 92, 90, 90, 91, 88, 89, 93, 90, 102, 88};
int S3_ADC[] = {408, 425, 420, 413, 408, 415, 406, 399, 405, 399, 398, 400, 414, 410, 413, 399, 418, 416, 412, 406};
int S4_ADC[] = {3941,3936,3918,3881, 3836, 3463, 2772, 2234, 1964, 1741, 1524, 1253, 1216, 1106, 1013, 971, 916, 815, 779, 779, 750, 654, 647};



/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM10_Init(void);
static void MX_TIM5_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void ADC_Init_Custom(){

	  hadc1.Instance = ADC1;
	  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
	  hadc1.Init.ScanConvMode = ENABLE;
	  hadc1.Init.ContinuousConvMode = ENABLE;
	  hadc1.Init.DiscontinuousConvMode = DISABLE;
	  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	  hadc1.Init.NbrOfConversion = 1;
	  hadc1.Init.DMAContinuousRequests = DISABLE;
	  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	  if (HAL_ADC_Init(&hadc1) != HAL_OK)
	  {
	    Error_Handler();
	  }

}

uint32_t ADC_SelectCH(uint32_t Channel){

	ADC_ChannelConfTypeDef sConfig = {0};
	uint32_t result;

	  sConfig.Channel = Channel;
	  sConfig.Rank = 1;
	  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		Error_Handler();
	  }

	HAL_ADC_Start(&hadc1);
	HAL_ADC_PollForConversion(&hadc1, 100);
	result= HAL_ADC_GetValue(&hadc1);
	HAL_ADC_Stop(&hadc1);
	return result;
}

void cambio_sensor();
float valor_voltaje(uint32_t adc);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM10_Init();
  MX_USB_DEVICE_Init();
  MX_TIM5_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  ADC_Init_Custom();
  HAL_TIM_Base_Start(&htim4);
  HAL_TIM_Base_Start(&htim1);
  HAL_TIM_Base_Start(&htim5);
  HAL_TIM_PWM_Start(&htim10, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

  while (1)
  {

	 if(indiceRX!=0){
		 if(indiceRX>=3 || (espera=__HAL_TIM_GET_COUNTER(&htim5)) >= 5000) { //HA PASADO 1S ¿?
			 seleccionarModo(datosRX);
			 voltpwm(volts_);
			 //valorRPM(mm_deseados);
			 __HAL_TIM_SET_COUNTER(&htim5,0);
			 counter++;
		 }
	 }

	 /*while(1){
		encoder_1= __HAL_TIM_GET_COUNTER(&htim4);
		encoder_2= __HAL_TIM_GET_COUNTER(&htim1);

		if (encoder_2 != objetivo){
			 if(objetivo > encoder_2){
			 voltpwm(volts_);
			 }else{
				 voltpwm(volts_*(-1));
			 }

		 }else
		 voltpwm(0);
	 }*/

	 if((espera =__HAL_TIM_GET_COUNTER(&htim5))>= 5000 && giro==1  ){ //1250 eq a 0.25 s
			  encoder_1= __HAL_TIM_GET_COUNTER(&htim4);
			  encoder_2= __HAL_TIM_GET_COUNTER(&htim1);
			  velocidad_m1 = (encoder_1-anterior_e1);
			  velocidad_m2 = (encoder_2-anterior_e2);
			  anterior_e2=encoder_2;
			  anterior_e1= encoder_1;
			  __HAL_TIM_SET_COUNTER(&htim5,0);
			  espera1++;

	 }

	 if(flag==2){
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0);//DERECHA
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,0);
			HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,0);
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,0);
			__HAL_TIM_SET_COUNTER(&htim4,0);
			__HAL_TIM_SET_COUNTER(&htim1,0);
			anterior_e2=0;
			anterior_e1=0;
			velocidad_m1=0;
			velocidad_m2=0;
			encoder_1=0;
			encoder_2=0;
			giro=0;
			espera1=0;
	 }
	 /*if(velocidad_m1 == 0 && velocidad_m2==0 && counter!=0){
	 				  __HAL_TIM_SET_COUNTER(&htim4,0);
	 				 __HAL_TIM_SET_COUNTER(&htim4,1);
	 				  anterior_e2=0;
	 				  anterior_e1=0;
	 			  }*/




	  cambio_sensor();

	  if(flag==1){
	  sprintf(texto,"%d %d \n", velocidad_m1, velocidad_m2 );
	  CDC_Transmit_FS(texto, strlen(texto));
	  //flag=0;
	  }



    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 4;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = 4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 16-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 200;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 0;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim4, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 19200-1;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 65535;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * @brief TIM10 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM10_Init(void)
{

  /* USER CODE BEGIN TIM10_Init 0 */

  /* USER CODE END TIM10_Init 0 */

  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM10_Init 1 */

  /* USER CODE END TIM10_Init 1 */
  htim10.Instance = TIM10;
  htim10.Init.Prescaler = 16-1;
  htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim10.Init.Period = 200;
  htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim10, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM10_Init 2 */

  /* USER CODE END TIM10_Init 2 */
  HAL_TIM_MspPostInit(&htim10);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_12|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA5 PA6 PA7 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB12 PB3 PB4
                           PB5 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_12|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void RecibirDatos (uint8_t* Buf, uint8_t Len){
	memcpy(datosRX+indiceRX, Buf, Len);
	indiceRX+=Len;
	__HAL_TIM_SET_COUNTER(&htim5,0);
}
void seleccionarModo(uint8_t datos[64]){

	/*if (datos[0] == 45) {//se verifica si tiene signo negativo
		negativo=1;
		mm_deseados=datosRX[1];
	}else{
		negativo=0;
		mm_deseados=datosRX[0];
	}*/

	if (datos[0] >= '0' && datos[0] <= '9') {
	    if (datos[1] >= '0' && datos[1] <= '9') {
	        // Caso para números de dos dígitos (10)
	        volts_ = (datos[0] - '0') * 10 + (datos[1] - '0');
	    } else {
	        // Caso para un solo dígito (1-9)
	       volts_= datos[0] - '0';
	    }

	}

	memset(datosRX,0,sizeof(datosRX));
	indiceRX=0;

}

void voltpwm(int voltios){

	if(voltios>=1){
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0);//DERECHA M1
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,1);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,1); // M2
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,0);
		pwm_cp=(cpDefinido*voltios)/motorVolts;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, pwm_cp);
		__HAL_TIM_SET_COMPARE(&htim10, TIM_CHANNEL_1, pwm_cp);
		__HAL_TIM_SET_COUNTER(&htim5,0);
		giro=1;
		flag=1;

	}

	if(voltios<1 || mm_deseados==27 ){//apagado
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1);//IZQUIERDA M1
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,0);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,0);//M2
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,1);
		pwm_cp= (cpDefinido*abs(voltios))/motorVolts;
		__HAL_TIM_SET_COMPARE(&htim10, TIM_CHANNEL_1, pwm_cp);
	}
}

void valorRPM (uint16_t rpms){

	if(negativo == 0){//Derecha
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,0);
		volts = (rpms-385.71)/744.64;
		voltpwm(volts);
	}
	if (negativo == 1) {//se verifica si tiene signo negativo (Izquierda
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,1);
		volts = abs((rpms-385.71)/744.64);
		voltpwm(volts);
	}


}

float valor_voltaje(uint32_t adc){ //Función para convertir de adc a volts
	float voltios=(adc*3.3)/4095;
	return voltios;
}

void cambio_sensor(){
	  if(contador==0){
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,1);
		  while(veces != 11){
			  S1 = ADC_SelectCH(ADC_CHANNEL_0);
			  if(veces!=0){
					  S1_acum+=S1;
			  }
			  veces++;
		  }
		  adc=(S1_acum/8);
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,0);


		  for(int i=0; i<22; i++){
			  if(adc<S1_ADC[21]){
				  mm_1=115;
				  S1_acum=0;
				  veces=0;
			  }
			  if(adc==S1_ADC[i]){
				  mm_1=5*(i+1);

			 }
			  else if(adc>S1_ADC[i] && adc<S1_ADC[i-1]){
				  int y1=mms[i];
				  int y2=mms[i-1];
				  float x1= valor_voltaje(S1_ADC[i]);
				  float x2= valor_voltaje(S1_ADC[i-1]);
				  float m = (y2-y1)/(x2-x1);
				  float b= y1-(m*x1);
				  volts= valor_voltaje(adc);
				  mm_1= volts*m + b;
			  }
		  }
		  S1_acum=0;
		  veces=0;
		  contador++;
	  }
	  if(contador==1){
		  while(veces != 11){
			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,1);
			  S2 = ADC_SelectCH(ADC_CHANNEL_1);
			  veces++;
			  S2_acum+=S2;
		  }
		  adc = (S2_acum / veces);
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, 0);

		  for (int i = 0; i < 20; i++) {
		      if (adc < S2_ADC[19]) {
		          mm_2 = 100;
		          S2_acum = 0;
		          veces = 0;
		      }
		      // if(volts == volts_1[i]){
		      //     mm_1 = 5 * (i + 1);
		      // }
		      else if (adc > S2_ADC[i] && adc < S2_ADC[i - 1]) {
		          int y1 = mms[i];
		          int y2 = mms[i + 1];
		          float x1 = valor_voltaje(S2_ADC[i]);
		          float x2 =  valor_voltaje(S2_ADC[i + 1]);
		          float m = (y2 - y1) / (x2 - x1);
		          float b = y1 - (m * x1);
		          mm_2 = valor_voltaje(adc) * m + b;
		      }
		  }


		  S2_acum=0;
		  veces=0;
		  contador++;
		  //__HAL_TIM_SET_COUNTER(&htim1,0);
	  }
	  if(contador==2){
		  while(veces != 11){
			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,1);
			  S3 = ADC_SelectCH(ADC_CHANNEL_2);
			  veces++;
			  S3_acum+=S3;

		  }

		  adc = (S3_acum / veces);
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, 0);

		  for (int i = 0; i < 20; i++) {
		      if (adc < S3_ADC[19]) {
		          mm_3 = 100;
		          S3_acum = 0;
		          veces = 0;
		      }
		      // if(volts == volts_1[i]){
		      //     mm_1 = 5 * (i + 1);
		      // }
		      else if (adc > S3_ADC[i] && adc < S3_ADC[i - 1]) {
		          int y1 = mms[i];
		          int y2 = mms[i + 1];
		          float x1 = valor_voltaje(S3_ADC[i]);
		          float x2 = S3_ADC[i - 1];
		          float m = (y2 - y1) / (x2 - x1);
		          float b = y1 - (m * x1);
		          mm_3 = valor_voltaje(adc) * m + b;
		      }
		  }

		  S3_acum=0;
		  veces=0;
		  contador++;
		  //__HAL_TIM_SET_COUNTER(&htim1,0);

	  }
	  if(contador==3){
		  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0,1);
		  while(veces != 11){
			  S4 = ADC_SelectCH(ADC_CHANNEL_3);
			  S4_acum+=S4;
			  veces++;
		  }
		  adc = (S4_acum / veces);
		  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, 1);

		  for (int i = 0; i < 22; i++) {
		      if (adc < S4_ADC[21]) {
		          mm_4 = 115;
		          S4_acum = 0;
		          veces = 0;
		      }
		      else if (adc > S4_ADC[i] && adc < S4_ADC[i - 1]) {
		          int y1 = mms[i];
		          int y2 = mms[i - 1];
		          float x1 = valor_voltaje(S4_ADC[i]);
		          float x2 = valor_voltaje(S4_ADC[i - 1]);
		          float m = (y2 - y1) / (x2 - x1);
		          float b = y1 - (m * x1);
		          volts= valor_voltaje(adc);
		          mm_4 = volts * m + b;
		      }
		  }

		  S4_acum=0;
		  veces=0;
		  contador=0;
		  //flag=1;
	  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
