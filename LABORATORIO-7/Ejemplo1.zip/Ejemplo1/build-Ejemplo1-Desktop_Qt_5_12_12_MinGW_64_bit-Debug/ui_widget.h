/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *label_rpm;
    QLabel *label_3;
    QComboBox *comboPuertos;
    QLabel *label_2;
    QPushButton *ButtonAbrir;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *rpmEdit;
    QPushButton *ButtonSetRPM;
    QPushButton *ButtonAdd;
    QCustomPlot *customPlot;
    QWidget *widget;
    QFormLayout *formLayout;
    QGridLayout *gridLayout_2;
    QLabel *label_5;
    QLabel *label_4;
    QGridLayout *gridLayout;
    QLabel *label_6;
    QLabel *label_7;
    QGridLayout *gridLayout_3;
    QLabel *label_8;
    QLabel *label_9;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->setEnabled(true);
        Widget->resize(800, 600);
        Widget->setMinimumSize(QSize(600, 300));
        Widget->setMaximumSize(QSize(1200, 1200));
        QFont font;
        font.setPointSize(16);
        Widget->setFont(font);
        label_rpm = new QLabel(Widget);
        label_rpm->setObjectName(QString::fromUtf8("label_rpm"));
        label_rpm->setGeometry(QRect(290, 100, 241, 101));
        QFont font1;
        font1.setPointSize(48);
        label_rpm->setFont(font1);
        label_3 = new QLabel(Widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(560, 100, 171, 101));
        comboPuertos = new QComboBox(Widget);
        comboPuertos->setObjectName(QString::fromUtf8("comboPuertos"));
        comboPuertos->setGeometry(QRect(100, 50, 101, 31));
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 50, 71, 16));
        QFont font2;
        font2.setPointSize(12);
        label_2->setFont(font2);
        ButtonAbrir = new QPushButton(Widget);
        ButtonAbrir->setObjectName(QString::fromUtf8("ButtonAbrir"));
        ButtonAbrir->setGeometry(QRect(210, 50, 81, 31));
        layoutWidget = new QWidget(Widget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 0, 550, 44));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        rpmEdit = new QLineEdit(layoutWidget);
        rpmEdit->setObjectName(QString::fromUtf8("rpmEdit"));

        horizontalLayout->addWidget(rpmEdit);

        ButtonSetRPM = new QPushButton(layoutWidget);
        ButtonSetRPM->setObjectName(QString::fromUtf8("ButtonSetRPM"));

        horizontalLayout->addWidget(ButtonSetRPM);

        ButtonAdd = new QPushButton(layoutWidget);
        ButtonAdd->setObjectName(QString::fromUtf8("ButtonAdd"));

        horizontalLayout->addWidget(ButtonAdd);

        customPlot = new QCustomPlot(Widget);
        customPlot->setObjectName(QString::fromUtf8("customPlot"));
        customPlot->setGeometry(QRect(0, 260, 801, 341));
        widget = new QWidget(Widget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(20, 120, 253, 121));
        formLayout = new QFormLayout(widget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font);

        gridLayout_2->addWidget(label_5, 0, 0, 1, 1);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font);

        gridLayout_2->addWidget(label_4, 0, 1, 1, 1);


        formLayout->setLayout(0, QFormLayout::LabelRole, gridLayout_2);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font);

        gridLayout->addWidget(label_6, 0, 0, 1, 1);

        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 0, 1, 1, 1);


        formLayout->setLayout(1, QFormLayout::LabelRole, gridLayout);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_8 = new QLabel(widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font);

        gridLayout_3->addWidget(label_8, 0, 0, 1, 1);

        label_9 = new QLabel(widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_3->addWidget(label_9, 0, 1, 1, 1);


        formLayout->setLayout(2, QFormLayout::LabelRole, gridLayout_3);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        label_rpm->setText(QApplication::translate("Widget", "00000", nullptr));
        label_3->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:48pt;\">RPM</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("Widget", "Puertos", nullptr));
        ButtonAbrir->setText(QApplication::translate("Widget", "Abrir", nullptr));
        label->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:12pt;\">RPM Actuales: </span></p></body></html>", nullptr));
        ButtonSetRPM->setText(QApplication::translate("Widget", "Set RPM", nullptr));
        ButtonAdd->setText(QApplication::translate("Widget", "APAGAR", nullptr));
        label_5->setText(QApplication::translate("Widget", "Tiempo", nullptr));
        label_4->setText(QApplication::translate("Widget", "TextLabel", nullptr));
        label_6->setText(QApplication::translate("Widget", "TMAX", nullptr));
        label_7->setText(QApplication::translate("Widget", "TextLabel", nullptr));
        label_8->setText(QApplication::translate("Widget", "RPM_MAX", nullptr));
        label_9->setText(QApplication::translate("Widget", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
