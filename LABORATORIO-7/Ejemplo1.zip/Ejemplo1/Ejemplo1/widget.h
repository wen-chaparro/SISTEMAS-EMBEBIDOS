#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QVector>
#include <QSerialPort>
#include <QSerialPortInfo>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void makeplot(int rpm, int tmax);

    void on_ButtonSetRPM_clicked();

    void on_ButtonAdd_clicked();

    void on_ButtonAbrir_clicked();

    void readyread();

    void processSerial(QByteArray datos_ );

private:
    Ui::Widget *ui;

    void setupPlot();
   //double x[100],y[100];
   QVector<double> x;
   QVector<double> y;

   int firstTime=0;
   QByteArray serialData;
   QString serialBuffer;
   QString parsed_data;
   QByteArray datos;
   QByteArray buffer;
   int contador = 0;
   int RPM=0;
   int RPM_MAX=0;
   int rpmanterior=0;
   int tiempo=0;
   int TMAX=0;
   char counter=0;
   char FLAG=0;
   uint8_t byte1=0;
   uint8_t byte2=0;
   uint8_t byte3=0;
   uint8_t byte4=0;

   QSerialPort *ttl = nullptr;
};
#endif // WIDGET_H
