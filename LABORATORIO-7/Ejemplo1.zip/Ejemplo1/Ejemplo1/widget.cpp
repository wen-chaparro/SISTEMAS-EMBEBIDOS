#include "widget.h"
#include "ui_widget.h"
#include <QVector>
#include <QDebug>
#include <QSerialPort>
#include <QSerialPortInfo>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    qDebug()<<"App iniciada ";
    ui->rpmEdit->setText(QString::number(contador));
    ui->label_rpm->setText(QString::number(contador));

    ttl = new QSerialPort(this);

    foreach (const QSerialPortInfo &serialport, QSerialPortInfo::availablePorts()) {
        QString nombrePuerto = serialport.portName();
        qDebug()<<nombrePuerto;
        ui->comboPuertos->addItem(nombrePuerto);
    }

    Widget:setupPlot();

}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_ButtonSetRPM_clicked()
{
    QByteArray datos;
    QString rpm_txt = ui->rpmEdit->text();
    contador = rpm_txt.toInt();

     // Manejo del contador negativo
     if (contador < 0) {
         contador = contador * -1;  // Convierte el contador en positivo
         datos.append(0x2D);        // Agrega el signo negativo '-'
         ttl->write(datos);         // Envía el signo
         datos.clear();
         datos.append(contador>>16);  // Agrega el byte menos significativo
         ttl->write(datos);       // Envía el LSB
         qDebug() << contador;// Limpia después de enviar
     }

    // Muestra el valor de contador en la consola

     datos.clear();
     datos.append(contador);  // Agrega el byte menos significativo
     ttl->write(datos);
     datos.clear();// Limpia el vector
     datos.append(contador >> 8);  // Agrega el byte más significativo
     ttl->write(datos);
     datos.clear();           // Limpia nuevamente






}

void Widget::setupPlot(){

    x.resize(101);
    y.resize(101);


    for (int i=0; i<101; ++i)
    {
      x[i] = (int)i;
      y[i] = (int)2;
    }

    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis2);
    ui->customPlot->graph(0)->setData(x, y);
    ui->customPlot->graph(0)->setName("RPM");
    ui->customPlot->plotLayout()->insertRow(0);
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPTextElement(ui->customPlot, "Velocidad - Motor DC", QFont("sans", 12, QFont::Bold)));


    ui->customPlot->legend->setVisible(true);
    QFont legendFont = font();  // start out with MainWindow's font..
    legendFont.setPointSize(9); // and make a bit smaller for legend
    ui->customPlot->legend->setFont(legendFont);
    ui->customPlot->legend->setBrush(QBrush(QColor(255,255,255,230)));
    // by default, the legend is in the inset layout of the main axis rect. So this is how we access it to change legend placement:
    //ui->customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignBottom|Qt::AlignRight);

    ui->customPlot->xAxis->setLabel("Time Relative");
    ui->customPlot->yAxis->setLabel("RPM.");
    ui->customPlot->xAxis->setRange(0, 100);
    ui->customPlot->yAxis->setRange(0, 6000);
    ui->customPlot->replot();
}

void Widget::makeplot(int rpm, int tmax){

    for (int i=0; i<100; ++i)
    {
      y[i] = y[i + 1];
    }
    y[100] = rpm;
    ui->customPlot->graph(0)->setData(x, y);
    ui->customPlot->replot();
}

void Widget::readyread()
{
    // Leer los datos recibidos en buffer
    buffer = ttl->readAll();
    qDebug() << buffer;


    serialData.append(buffer);
    //Aqui se analizan los datos del protocolo
    //Se debe tener en cuenta el caso de "else" cuando no cumple con el protocolo
    //Aquí no está desarrollado el protocolo, deben poner la parte que ustedes desarrollaron
    if(firstTime==1) {
        ui->label_rpm->setText(QString::number(RPM));
    }
    if(serialData.at(0) == 0X0E && firstTime==1 && serialData.at(serialData.length()-1)==0x0F){
        //Una vez analizado el protocolo, los datos deben ser enviados a la siguiente funcion:
        processSerial(serialData);
        firstTime=0;
       serialData.clear();
    }else if(serialData.at(0) != 0X0E && firstTime ==0){
        serialData.clear();
    }else if(serialData.at(0) == 0X0E && firstTime==0 ){
        firstTime=1;
    }


}

void Widget::processSerial(QByteArray datos_){

    //Aquí llegan los datos del puerto serial, se deben tomar las acciones necesarias, como graficar etc.
    qDebug()<< datos;



    byte1= datos_.at(3);
    byte2= datos_.at(4);
    byte3= datos_.at(6);
    byte4= datos_.at(5);

    RPM = (byte1 << 8) | (byte2) ;
    RPM = (RPM << 8) |  byte4 ;
    RPM = (RPM << 8) | byte3 ;


    byte3= datos_.at(9);
    byte4= datos_.at(10);

    TMAX = (byte3 << 8) | byte4 ;
    if(RPM == rpmanterior){
        RPM_MAX = RPM;
        counter++;
        if(counter>=1 && FLAG==0){
            tiempo= TMAX;
            FLAG=1;
       }
    }
    if(TMAX == 0 ){
        TMAX = 0;
        RPM = 0;
        counter=0;
        tiempo=0;
        RPM_MAX=0;
    }

    ui->label_rpm->setText(QString::number(RPM));
    ui->label_4->setText(QString::number(TMAX));
    ui->label_7->setText(QString::number(RPM_MAX));
    ui->label_9->setText(QString::number(tiempo));
    qDebug() <<"Datos:     " << QString::number(TMAX);



    rpmanterior= RPM;

    makeplot(RPM, TMAX);




}

void Widget::on_ButtonAdd_clicked()
{
    qDebug()<<"boton pulsado";
    contador++;
    ui->label_rpm->setText(QString::number(contador));

    datos.clear();
    datos.append(27);
    ttl->write(datos);
    
}

void Widget::on_ButtonAbrir_clicked()
{
    QString portname = ui->comboPuertos->currentText();

    if(ui->ButtonAbrir->text() == "Abrir"){
        ttl->close();
        ttl->setPortName(portname);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->open(QSerialPort::ReadWrite);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setFlowControl(QSerialPort::NoFlowControl);
        ttl->setParity(QSerialPort::NoParity);
        connect(ttl,SIGNAL(readyRead()),this,SLOT(readyread()));
        ui->ButtonAbrir->setText("Cerrar");
    }else{
        ttl->close();
        disconnect(ttl,SIGNAL(readyRead()),this,SLOT(readyread()));
        ui->ButtonAbrir->setText("Abrir");
    }



}




