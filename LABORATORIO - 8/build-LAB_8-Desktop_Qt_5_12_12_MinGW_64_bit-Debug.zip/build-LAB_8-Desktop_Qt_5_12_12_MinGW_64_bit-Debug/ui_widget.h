/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include <qcustomplot.h>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QCustomPlot *customPlot;
    QComboBox *comboPuertos;
    QProgressBar *progressBar;
    QProgressBar *progressBar_2;
    QProgressBar *progressBar_3;
    QProgressBar *progressBar_4;
    QPushButton *ButtonAbrir;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(800, 600);
        customPlot = new QCustomPlot(Widget);
        customPlot->setObjectName(QString::fromUtf8("customPlot"));
        customPlot->setGeometry(QRect(10, 300, 771, 291));
        comboPuertos = new QComboBox(Widget);
        comboPuertos->setObjectName(QString::fromUtf8("comboPuertos"));
        comboPuertos->setGeometry(QRect(30, 10, 81, 31));
        progressBar = new QProgressBar(Widget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(260, 180, 41, 111));
        progressBar->setValue(24);
        progressBar->setOrientation(Qt::Vertical);
        progressBar_2 = new QProgressBar(Widget);
        progressBar_2->setObjectName(QString::fromUtf8("progressBar_2"));
        progressBar_2->setGeometry(QRect(40, 120, 151, 41));
        progressBar_2->setValue(24);
        progressBar_3 = new QProgressBar(Widget);
        progressBar_3->setObjectName(QString::fromUtf8("progressBar_3"));
        progressBar_3->setGeometry(QRect(610, 110, 151, 41));
        progressBar_3->setValue(0);
        progressBar_4 = new QProgressBar(Widget);
        progressBar_4->setObjectName(QString::fromUtf8("progressBar_4"));
        progressBar_4->setGeometry(QRect(500, 180, 41, 111));
        progressBar_4->setValue(24);
        progressBar_4->setOrientation(Qt::Vertical);
        ButtonAbrir = new QPushButton(Widget);
        ButtonAbrir->setObjectName(QString::fromUtf8("ButtonAbrir"));
        ButtonAbrir->setGeometry(QRect(140, 10, 101, 31));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        progressBar->setFormat(QApplication::translate("Widget", "%p", nullptr));
        progressBar_2->setFormat(QApplication::translate("Widget", "%p", nullptr));
        progressBar_3->setFormat(QApplication::translate("Widget", "%p", nullptr));
        progressBar_4->setFormat(QApplication::translate("Widget", "%p", nullptr));
        ButtonAbrir->setText(QApplication::translate("Widget", "ABRIR", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
