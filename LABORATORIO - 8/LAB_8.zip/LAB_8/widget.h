#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QVector>
#include <QSerialPort>
#include <QSerialPortInfo>


QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void makeplot(int rpm, int tmax);

    void on_comboBox_activated(const QString &arg1);

    void readyread();

    void processSerial(QByteArray datos_ );

    void on_ButtonAbrir_clicked();

private:
    Ui::Widget *ui;

    QVector<double> x;
    QVector<double> y;
    QByteArray serialData;
    QString serialBuffer;
    QString parsed_data;
    QByteArray datos;
    QByteArray buffer;
    void setupPlot();
    int byte1=0;
    int byte2=0;
    int byte3=0;
    int byte4=0;
    int S1=0;
    int S2=0;
    int S3=0;
    int S4=0;
    QSerialPort *ttl = nullptr;
};
#endif // WIDGET_H
