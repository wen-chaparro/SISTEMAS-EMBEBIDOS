#include "widget.h"
#include "ui_widget.h"
#include <QVector>
#include <QDebug>
#include <QSerialPort>
#include <QSerialPortInfo>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    ui->progressBar->setRange(0,100);
   ui->progressBar_2->setRange(0,100);
   ui->progressBar_3->setRange(0,100);
   ui->progressBar_4->setRange(0,100);
   ui->progressBar->setValue(0);
   ui->progressBar_2->setValue(0);
   ui->progressBar_3->setValue(0);
   ui->progressBar_4->setValue(0);


    qDebug()<<"App iniciada ";

    ttl = new QSerialPort(this);

    foreach (const QSerialPortInfo &serialport, QSerialPortInfo::availablePorts()) {
        QString nombrePuerto = serialport.portName();
        qDebug()<<nombrePuerto;
        ui->comboPuertos->addItem(nombrePuerto);

    }

    Widget:setupPlot();

}

Widget::~Widget()
{
    delete ui;
}


void Widget::setupPlot(){

    x.resize(101);
    y.resize(101);


    for (int i=0; i<101; ++i)
    {
      x[i] = (int)i;
      y[i] = (int)2;
    }

    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis2);
    ui->customPlot->graph(0)->setData(x, y);
    ui->customPlot->graph(0)->setName("SENSOR");
    ui->customPlot->plotLayout()->insertRow(0);
    ui->customPlot->plotLayout()->addElement(0, 0, new QCPTextElement(ui->customPlot, "Velocidad - Motor DC", QFont("sans", 12, QFont::Bold)));


    ui->customPlot->legend->setVisible(true);
    QFont legendFont = font();  // start out with MainWindow's font..
    legendFont.setPointSize(9); // and make a bit smaller for legend
    ui->customPlot->legend->setFont(legendFont);
    ui->customPlot->legend->setBrush(QBrush(QColor(255,255,255,230)));
    // by default, the legend is in the inset layout of the main axis rect. So this is how we access it to change legend placement:
    //ui->customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignBottom|Qt::AlignRight);

    ui->customPlot->xAxis->setLabel("Time Relative");
    ui->customPlot->yAxis->setLabel("SENSOR");
    ui->customPlot->xAxis->setRange(0, 100);
    ui->customPlot->yAxis->setRange(0, 6000);
    ui->customPlot->replot();
}

void Widget::makeplot(int rpm, int tmax){

    for (int i=0; i<100; ++i)
    {
      y[i] = y[i + 1];
    }
    y[100] = S1;
    ui->customPlot->graph(0)->setData(x, y);
    ui->customPlot->replot();
}

void Widget::readyread()
{
    // Leer los datos recibidos en buffer
    buffer = ttl->readAll();



    byte1= buffer.at(0);
    byte2= buffer.at(1);
    byte3= buffer.at(4);
    byte4= buffer.at(5);

    S1 =  (byte1) ;
    //S1 = (S1 << 8) |  (byte2) ;
    //S1 = (S1 << 8) |  (byte3) ;
    S4 = (byte3 << 8) |  (byte4) ;

    qDebug() << byte1;

    ui->progressBar_2->setValue(S1);
    ui->progressBar->setValue(S2);
    ui->progressBar_4->setValue(S3);
    ui->progressBar_3->setValue(S4);

    //serialData.append(buffer);
    //processSerial(serialData);
    //Aqui se analizan los datos del protocolo
    //Se debe tener en cuenta el caso de "else" cuando no cumple con el protocolo
    //Aquí no está desarrollado el protocolo, deben poner la parte que ustedes desarrollaron
    /*if(firstTime==1) {
        ui->label_rpm->setText(QString::number(RPM));
    }
    if(serialData.at(0) == 0X0E && firstTime==1 && serialData.at(serialData.length()-1)==0x0F){
        //Una vez analizado el protocolo, los datos deben ser enviados a la siguiente funcion:

        firstTime=0;
       serialData.clear();
    }else if(serialData.at(0) != 0X0E && firstTime ==0){
        serialData.clear();
    }else if(serialData.at(0) == 0X0E && firstTime==0 ){
        firstTime=1;
    }*/


}

void Widget::processSerial(QByteArray datos_){

    //Aquí llegan los datos del puerto serial, se deben tomar las acciones necesarias, como graficar etc.
    qDebug()<< datos;




    //makeplot(RPM, TMAX);




}





void Widget::on_ButtonAbrir_clicked()
{
    QString portname = ui->comboPuertos->currentText();

    if(ui->ButtonAbrir->text() == "Abrir"){
        ttl->close();
        ttl->setPortName(portname);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->open(QSerialPort::ReadWrite);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setFlowControl(QSerialPort::NoFlowControl);
        ttl->setParity(QSerialPort::NoParity);
        connect(ttl,SIGNAL(readyRead()),this,SLOT(readyread()));
        ui->ButtonAbrir->setText("Cerrar");
    }else{
        ttl->close();
        disconnect(ttl,SIGNAL(readyRead()),this,SLOT(readyread()));
        ui->ButtonAbrir->setText("Abrir");
    }

}

