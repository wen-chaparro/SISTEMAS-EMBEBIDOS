#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>
#include <QSerialPortInfo>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_set_RPM_clicked();

    void on_add_clicked();

    void on_botonAbrir_clicked();

    void readyread();

    void on_izquierda_clicked();

    void on_derecha_clicked();

    void on_off_clicked();

private:
    Ui::Widget *ui;
    int contador= 500;
    uint RPM=0;
    uint8_t byte1=0;
    uint8_t byte2=0;
    uint8_t byte3=0;
    uint8_t byte4=0;
    QSerialPort *ttl= nullptr;
};
#endif // WIDGET_H
