#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QSerialPort>
#include <QSerialPortInfo>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);


    qDebug() << "App iniciada" << contador; // De esta forma se puede hacer "Debug"
    ui->label_RPM->setText(QString::number(RPM));
    ttl= new QSerialPort(this);

    foreach (const QSerialPortInfo &serialport, QSerialPortInfo::availablePorts() ){
        QString nombrePuertos = serialport.portName();
        qDebug()<<nombrePuertos;
        ui->Puertos->addItem(nombrePuertos);
    }
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_set_RPM_clicked()// Izquierda motor
{

    qDebug() <<"boton_pulsado_Izquierda";
    QByteArray datos;
    datos.append(0x31);
    ttl->write(datos);



   ui->label_RPM->setText(QString::number(contador));
}


void Widget::on_add_clicked()//Derecha motor
{
    qDebug() <<"boton_pulsado_Derecha";
    QByteArray datos;
    datos.append(0x30);
    ttl->write(datos);
}


void Widget::on_botonAbrir_clicked()
{
    QString portname = ui->Puertos->currentText();

    if(ui->botonAbrir->text() == "Abrir"){
        ttl->close();
        ttl->setPortName(portname);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->open(QSerialPort::ReadWrite);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setFlowControl(QSerialPort::NoFlowControl);
        ttl->setParity(QSerialPort::NoParity);
        connect(ttl,SIGNAL(readyRead()),this, SLOT(readyread()));
        ui->botonAbrir->setText("cerrar");

    } else {
        ttl->close();
        disconnect(ttl,SIGNAL(readyRead()),this, SLOT(readyread()));
        ui->botonAbrir->setText("Abrir");
    }


}

void Widget::readyread()
{
    QByteArray buffer = ttl->readAll();
    qDebug()<<buffer;



    byte1= buffer.at(3);
    byte2= buffer.at(4);
    byte3= buffer.at(6);
    byte4= buffer.at(5);

    RPM = (byte1 << 8) | byte2 ;
    RPM = (RPM << 8) | byte4 ;
    RPM = (RPM << 8) | byte3 ;
    ui->label_RPM->setText(QString::number(RPM));
     qDebug() <<"Datos:     " << QString::number(RPM,16);
}


void Widget::on_off_clicked()//APAGADO MOTOR
{
    qDebug() <<"boton_pulsado_Apagado";
    QByteArray datos;
    datos.append(0x1B);
    ttl->write(datos);
}

