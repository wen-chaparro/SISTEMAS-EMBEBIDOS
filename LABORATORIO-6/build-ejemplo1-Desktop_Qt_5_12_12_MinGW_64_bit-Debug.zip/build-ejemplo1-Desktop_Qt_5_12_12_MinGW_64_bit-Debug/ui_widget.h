/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *label_RPM;
    QLabel *RPM;
    QPushButton *set_RPM;
    QPushButton *add;
    QLabel *label_2;
    QComboBox *Puertos;
    QPushButton *botonAbrir;
    QPushButton *off;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(600, 300);
        Widget->setMaximumSize(QSize(600, 300));
        label_RPM = new QLabel(Widget);
        label_RPM->setObjectName(QString::fromUtf8("label_RPM"));
        label_RPM->setGeometry(QRect(120, 140, 151, 61));
        QFont font;
        font.setPointSize(34);
        label_RPM->setFont(font);
        RPM = new QLabel(Widget);
        RPM->setObjectName(QString::fromUtf8("RPM"));
        RPM->setGeometry(QRect(340, 150, 121, 51));
        RPM->setFont(font);
        set_RPM = new QPushButton(Widget);
        set_RPM->setObjectName(QString::fromUtf8("set_RPM"));
        set_RPM->setGeometry(QRect(300, 20, 61, 31));
        add = new QPushButton(Widget);
        add->setObjectName(QString::fromUtf8("add"));
        add->setGeometry(QRect(370, 20, 71, 31));
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 30, 55, 16));
        Puertos = new QComboBox(Widget);
        Puertos->setObjectName(QString::fromUtf8("Puertos"));
        Puertos->setGeometry(QRect(100, 30, 73, 22));
        botonAbrir = new QPushButton(Widget);
        botonAbrir->setObjectName(QString::fromUtf8("botonAbrir"));
        botonAbrir->setGeometry(QRect(190, 30, 93, 28));
        off = new QPushButton(Widget);
        off->setObjectName(QString::fromUtf8("off"));
        off->setGeometry(QRect(450, 20, 71, 31));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        label_RPM->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:26pt;\">0</span></p></body></html>", nullptr));
        RPM->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:24pt;\">RPM</span></p></body></html>", nullptr));
        set_RPM->setText(QApplication::translate("Widget", "Izquierda", nullptr));
        add->setText(QApplication::translate("Widget", "Derecha", nullptr));
        label_2->setText(QApplication::translate("Widget", "Puertos", nullptr));
        botonAbrir->setText(QApplication::translate("Widget", "Abrir", nullptr));
        off->setText(QApplication::translate("Widget", "Apagado", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
